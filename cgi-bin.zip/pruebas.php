<?php




echo rand ( 10000 , 99999 );
?>