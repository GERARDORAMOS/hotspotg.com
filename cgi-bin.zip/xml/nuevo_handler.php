<?php
session_start();
$_SESSION["origen"] = $_SERVER['HTTP_REFERER'];

switch ($_POST["func"]) {
   
    case 1: //FUNCIÓN DE SERVICIO

// ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}

            $sql = "SELECT * FROM service WHERE id_user = '".$_POST["usuario"]."' AND id_server = '".$_POST["usuario_taxista"]."' AND estado = '0'";
            $resultado = mysql_query($sql, $enlace);
            $fila2 = mysql_fetch_array($resultado);
            if($fila2[0] > null)
            {          

$sql = "UPDATE  `hotspotg_hotspot`.`service` SET  `time_finish` =  NOW(),`kbs_downloaded` =  '".$_POST["descarga"]."', `kbd_uploaded` =  '".$_POST["subida"]."' , `connection_speed` =  '".$_POST["velocidad"]."' WHERE id_user = '".$_POST["usuario"]."' AND id_server = '".$_POST["usuario_taxista"]."' AND estado = '0'";
                $resultado = mysql_query($sql, $enlace);
                mysql_free_result($resultado);

$fechaInicial = $fila2[3];
$fechaFinal = $fila2[4];
$segundos = strtotime($fechaFinal) - strtotime($fechaInicial);
$segundos2 = $segundos % 60;

                echo '99;'.$fila2[0].';'.$fila2[1].';'.$fila2[2].';'.$segundos.';'.number_format($segundos/60,0);

            }else{

$sql = "INSERT INTO  `hotspotg_hotspot`.`service` (
`id` ,
`id_user` ,
`id_server` ,
`time_start` ,
`time_finish` ,
`gps_server_start` ,
`gps_server_finish` ,
`gps_client_start` ,
`gps_client_finish` ,
`kbs_downloaded` ,
`kbd_uploaded` ,
`connection_speed` ,
`estado`
)
VALUES (
NULL ,  '".$_POST["usuario"]."',  '".$_POST["usuario_taxista"]."',  NOW(),  NOW(),  '".$_POST["gps_taxi"]."', '".$_POST["gps_taxi_final"]."' , '".$_POST["gps_usuario"]."' , '".$_POST["gps_usuario_final"]."' , '".$_POST["descarga"]."' , '".$_POST["subida"]."' , '".$_POST["velocidad"]."' ,  '".$_POST["estado"]."'
);";
                echo '55;Servicio registrado';

                $resultado = mysql_query($sql, $enlace);
                mysql_free_result($resultado);

}
    break;

    case 2: //FUNCIÓN DE LOGIN

// ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}
$sql = "UPDATE  `hotspotg_hotspot`.`service` SET  `time_finish` =  NOW(), `kbs_downloaded` =  '".$_POST["descarga"]."', `kbd_uploaded` =  '".$_POST["subida"]."' , `connection_speed` =  '".$_POST["velocidad"]."' WHERE id_user = '".$_POST["usuario"]."' AND id_server = '".$_POST["usuario_taxista"]."' AND estado = '0'";
                $resultado = mysql_query($sql, $enlace);
                mysql_free_result($resultado);

            $sql = "SELECT * FROM service WHERE id_user = '".$_POST["usuario"]."' AND id_server = '".$_POST["usuario_taxista"]."' AND estado = '0'";
            $resultado = mysql_query($sql, $enlace);
            $fila2 = mysql_fetch_array($resultado);
            if($fila2[0] != null)
            {          

$sql = "UPDATE  `hotspotg_hotspot`.`service` SET  `time_finish` =  NOW(),`gps_client_finish` =  '".$_POST["gps_usuario"]."',`kbs_downloaded` =  '".$_POST["descarga"]."', `kbd_uploaded` =  '".$_POST["subida"]."' , `connection_speed` =  '".$_POST["velocidad"]."', `estado` =  '".$_POST["estado"]."' WHERE id_user = '".$_POST["usuario"]."' AND id_server = '".$_POST["usuario_taxista"]."' AND estado = '0'";
                $resultado = mysql_query($sql, $enlace);
                mysql_free_result($resultado);

$fechaInicial = $fila2[3];
$fechaFinal = $fila2[4];
$segundos = strtotime($fechaFinal) - strtotime($fechaInicial);
$segundos2 = $segundos % 60;

                echo '77;'.$fila2[0].';'.$fila2[1].';'.$fila2[2].';'.$segundos.';'.number_format($segundos/60,0).':'.$segundos2;

            }else{
                echo '66; no se econtro red';

            }

break;


    case 3: //FUNCIÓN DE SUSCRIPCION lOGIN

// ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}
 $sql = "SELECT * FROM vendedor WHERE email = '".$_POST["usuario"]."' AND password = '".$_POST["clave"]."'";
          $resultado = mysql_query($sql, $enlace);
          $fila = mysql_fetch_array($resultado);
          if($fila[1] != null)
          {


              echo '99;'.$fila[0].';'.$fila[1].';'.$fila[2].';'.$fila[3].';'.$fila[4].';'.$fila[5].';'.$fila[6].';'.$fila[7].';'.$fila[8].';'.$fila[9].';'.$fila[10].';'.$fila[11].';'.$fila[12].';'.$fila[13];
              mysql_free_result($resultado);
              mysql_close($enlace );
          }else{
              echo '3;Usuario o contraseña incorrectos';
          }

    break;
    case 4: //FUNCIÓN DE CONSULTA usuario taxista

// ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}
 $sql = "SELECT usuario,documento_identidad,fecha_registro,cod_pais,celular,placa FROM user_taxi WHERE email = '".$_POST["email"]."' AND estado = '0'";
          $resultado = mysql_query($sql, $enlace);
          $fila = mysql_fetch_array($resultado);
          if($fila[1] != null)
          {
              echo '99;'.$fila[0].';'.$fila[1].';'.$fila[2].';'.$fila[3].';'.$fila[4].';'.$fila[5];
              mysql_free_result($resultado);
              mysql_close($enlace );
          }else{
              echo '3;El email '.$_POST["email"].' no registra en la base de datos.';
          }

    break;
    case 5: //FUNCIÓN DE suscribir usuario taxista

// ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}
 $sql = "SELECT usuario,documento_identidad,fecha_registro,cod_pais,celular,placa FROM user_taxi WHERE email = '".$_POST["email"]."' AND estado = '0'";
          $resultado = mysql_query($sql, $enlace);
          $fila = mysql_fetch_array($resultado);
          if($fila[1] != null)
          {

$sql = "UPDATE  `hotspotg_hotspot`.`user_taxi` SET  `estado` = '1', `id_vendedor` = '1' WHERE email = '".$_POST["email"]."' AND estado = '0'";
                $resultado = mysql_query($sql, $enlace);
                mysql_free_result($resultado);
              echo '99;Usuario inscrito correctamente.';


          }else{
              echo '3;El email '.$_POST["email"].' no registra en la base de datos...';
          }

    break;
    case 6: //FUNCIÓN  lOGIN TAXISTA

// ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}
 $sql = "SELECT * FROM user_taxi WHERE celular = '".$_POST["usuario"]."' AND password = '".$_POST["clave"]."';";
          $resultado = mysql_query($sql, $enlace);
          $fila = mysql_fetch_array($resultado);
          if($fila[0] != null)
          {


              echo '99;'.$fila[0].';'.$fila[1].';'.$fila[2].';'.$fila[3].';'.$fila[4].';'.$fila[5].';'.$fila[6].';'.$fila[7].';'.$fila[8].';'.$fila[9].';'.$fila[10].';'.$fila[11].';'.$fila[12].';'.$fila[13];
              mysql_free_result($resultado);
              mysql_close($enlace );
          }else{
              echo '3;Usuario o contraseña incorrectos';
          }

    break;
    case 7: //FUNCIÓN lOGIN USUARIO

// ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}
 $sql = "SELECT * FROM user_clientes WHERE email = '".$_POST["email"]."' AND password = '".$_POST["clave"]."'";
          $resultado = mysql_query($sql, $enlace);
          $fila = mysql_fetch_array($resultado);
          if($fila[1] != null)
          {


              echo '99;'.$fila[0].';'.$fila[1].';'.$fila[2].';'.$fila[3].';'.$fila[4].';'.$fila[5].';'.$fila[6].';'.$fila[7].';'.$fila[8].';'.$fila[9].';'.$fila[10].';'.$fila[11].';'.$fila[12].';'.$fila[13];
              mysql_free_result($resultado);
              mysql_close($enlace );
          }else{
              echo '3;Usuario o contraseña incorrectos';
          }

    break;


    case 8: //FUNCIÓN DE REGISTRO TAXISTA

     // ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}
          $sql = "SELECT COUNT( * ) FROM user_taxi WHERE email = '".$_POST["correo"]."'";
          $resultado = mysql_query($sql, $enlace);
          $fila = mysql_fetch_array($resultado);
          if($fila[0] > 0)
          {          
            echo utf8_decode('3;El correo electronico ya se encuentra registrado');
            mysql_free_result($resultado);
          }else{
            $sql = "SELECT COUNT( * ) FROM user_taxi WHERE usuario = '".$_POST["usuario"]."'";
            $resultado = mysql_query($sql, $enlace);
            $fila2 = mysql_fetch_array($resultado);
            if($fila2[0] > 0)
            {          
              echo '4;El nombre de usuario ya se encuentra registrado';
              mysql_free_result($resultado);
            }else{

$sql2 ="INSERT INTO `hotspotg_hotspot`.`user_taxi` (`id_usuario`, `usuario`, `email`, `documento_identidad`, `password`, `fecha_registro`, `cod_pais`, `celular`, `placa`, `device_id`, `latitud`, `longitud`, `direccion`, `estado`, `id_vendedor`) VALUES (NULL, '".$_POST["usuario"]."', '".$_POST["correo"]."', '".$_POST["documento"]."', '".$_POST["clave"]."', CURRENT_TIMESTAMP, '+57', '".$_POST["celular"]."', '".$_POST["placa"]."', '".$_POST["device_id"]."', NULL, NULL, NULL, '0', '0');";

             
                $resultado2 = mysql_query($sql2, $enlace);

                if($resultado2 == "1")
                  echo utf8_decode('99;Usuario registrado'); 
                else
                  echo utf8_decode('5;No es posible realizar el registro.'); 


                mysql_free_result($resultado2);


            }
           }
          
          mysql_close($enlace );
    break;

    case 9: //FUNCIÓN DE conteo

     // ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}

          $sql = "SELECT COUNT( * ) FROM user_taxi";
          $resultado = mysql_query($sql, $enlace);
          $fila = mysql_fetch_array($resultado);
          if($fila[0] > 0)
          {          
            $sql = "SELECT COUNT( * ) FROM user_clientes";
            $resultado = mysql_query($sql, $enlace);
            $fila2 = mysql_fetch_array($resultado);

            $sql = "SELECT COUNT( * ) FROM service_ip";
            $resultado = mysql_query($sql, $enlace);
            $fila3 = mysql_fetch_array($resultado);
            echo '99;'.$fila[0].';'.$fila2[0].';'.$fila3[0]; 

            mysql_free_result($resultado);
            mysql_free_result($resultado2);
            mysql_close($enlace );          
           }


    break;

    case 10: //FUNCIÓN DE conteo servicio

     // ! delante de la variable indica  Si variable NO es TRUE
if (!$enlace = mysql_connect("localhost", "hotspotg_android", "TexasApplications713")) {
    echo '1;No pudo conectarse a mysql';
    exit;
}

if (!mysql_select_db('hotspotg_hotspot', $enlace)) {
    echo '2;No pudo seleccionar la base de datos';
    exit;
}

          $sql = "SELECT COUNT( * ) FROM user_taxi";
          $resultado = mysql_query($sql, $enlace);
          $fila = mysql_fetch_array($resultado);
          if($fila[0] > 0)
          {          
            $sql = "SELECT COUNT( * ) FROM user_clientes";
            $resultado = mysql_query($sql, $enlace);
            $fila2 = mysql_fetch_array($resultado);

            echo '99;'.$fila[0].';'.$fila2[0]; 

            mysql_free_result($resultado);
            mysql_free_result($resultado2);
            mysql_close($enlace );          
           }


    break;
}


?>