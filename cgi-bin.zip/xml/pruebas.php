<?php 


 ?>
<form action="http://www.hotspotg.com/xml/webService_servicio.php" method="post">
    login
    <p>Su funcion: <input type="text" name="func" value="1"/></p>
     <p>user_taxi: <input type="text" name="user_taxi"/></p>
     <p>id_user_taxi: <input type="text" name="id_user_taxi"/></p>
 <p><input type="submit" /></p>
</form>
<form action="http://www.hotspotg.com/xml/webService_servicio.php" method="post">
    login
    <p>Su funcion: <input type="text" name="func" value="2"/></p>
     <p>id_taxi: <input type="text" name="id_taxi"/></p>
     <p>ip_usuario: <input type="text" name="ip_usuario"/></p>
 <p><input type="submit" /></p>
</form>
<form action="http://www.hotspotg.com/xml/webService_servicio.php" method="post">
    login
    <p>Su funcion: <input type="text" name="func" value="3"/></p>
     <p>id_taxi: <input type="text" name="id_taxi"/></p>
     <p>tiempo: <input type="text" name="tiempo"/></p>
     <p>megas: <input type="text" name="megas"/></p>
     <p>estado: <input type="text" name="estado"/></p>
 <p><input type="submit" /></p>
</form>